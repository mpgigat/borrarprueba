const bd={
    personas:[],
    articulos:[],
    carrito:[]
}
const hora=()=>{}

export default bd
